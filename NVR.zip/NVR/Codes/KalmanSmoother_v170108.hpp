#ifndef KalmanSmoother_HPP
#define KalmanSmoother_HPP

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cmath>
#include<cassert>
#include<algorithm>

using namespace std;

class KalmanSmoother{
public:
/*
z(n)=z(n-1)+eps_z
x(n)=w(n)x(n)+eps_x
*/
	vector<double> x;//observed data
	vector<double> w;
	vector<double> z;
	double Sig_z;//Variance
	double mu_ini;//Mean for P(z(0))
	double Sig_ini;//Variance for P(z(0))
	double Sig_x;

	KalmanSmoother(){
	}//end KalmanSmoother
	KalmanSmoother(double Sig_z_,double mu_ini_,double Sig_ini_,double Sig_x_,vector<double> x_,vector<double> w_){
		Sig_z=Sig_z_;
		mu_ini=mu_ini_;
		Sig_ini=Sig_ini_;
		Sig_x=Sig_x_;
		x=x_;
		w=w_;
	}//end KalmanSmoother
	~KalmanSmoother(){}//end ~KalmanSmoother

	void Clear(){
	}//end Clear

	void Smooth(){
		int size=x.size();
		assert(w.size()==size);
		z.resize(size);

		vector<double> Sig(size);
		vector<double> mu(size);

		/// Viterbi update
		mu[0]=(mu_ini+w[0]*x[0]*Sig_ini/Sig_x)/(1+w[0]*w[0]*Sig_ini/Sig_x);
		Sig[0]=Sig_ini/(1+w[0]*w[0]*Sig_ini/Sig_x);
		for(int n=0;n<size-1;n+=1){
			mu[n+1]=(mu[n]+w[n+1]*x[n+1]*(Sig[n]+Sig_z)/Sig_x)/(1+w[n+1]*w[n+1]*(Sig[n]+Sig_z)/Sig_x);
			Sig[n+1]=(Sig[n]+Sig_z)/(1+w[n+1]*w[n+1]*(Sig[n]+Sig_z)/Sig_x);
		}//endfor n

		/// Backtrack
		z[size-1]=mu[size-1];
		for(int n=size-2;n>=0;n-=1){
			z[n]=(Sig[n]*z[n+1]+Sig_z*mu[n])/(Sig[n]+Sig_z);//z[n+1]
		}//endfor n

	}//end Smooth

};//end class Tr

#endif // KalmanSmoother

