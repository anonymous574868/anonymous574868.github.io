#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"Trx_v170203.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=3){
		cout<<"Error in usage: $./this in.mid out_trx.txt"<<endl;
		return -1;
	}//endif


	Trx trx;
	trx.ReadMIDIFile(string(argv[1]));
	trx.WriteFile(string(argv[2]));


//	end = clock(); cout<<"Elapsed time : "<<((double)(end - start) / CLOCKS_PER_SEC)<<" sec"<<endl; start=end;
	return 0;
}//end main

