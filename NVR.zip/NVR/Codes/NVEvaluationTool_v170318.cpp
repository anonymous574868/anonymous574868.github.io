#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include"NoteValueCalculation_v170108_2.hpp"
#include"Trx_v170203.hpp"
using namespace std;

int main(int argc,char** argv){

	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=3){
		cout<<"Error in usage! : $./this true_trx.txt est_trx.txt"<<endl; return -1;
	}//endif

	string trueFile=string(argv[1]);
	string estFile=string(argv[2]);

	Trx trTrue;
	trTrue.ReadFile(trueFile);
	Trx trEst;
	trEst.ReadFile(estFile);

	assert(trTrue.evts.size()==trEst.evts.size());
	int length=trTrue.evts.size();

	/// Note-value ratio error

	vector<int> IONVTrue(length);
	vector<int> IONVEst(length);
	for(int n=0;n<length;n+=1){
		IONVTrue[n]=-1;
		IONVEst[n]=-1;
		for(int m=n+1;m<length;m+=1){
			if(trTrue.evts[m].onstime>trTrue.evts[n].onstime){
				IONVTrue[n]=trTrue.evts[m].onstime-trTrue.evts[n].onstime;
				break;
			}//endif
		}//endfor m
		for(int m=n+1;m<length;m+=1){
			if(trEst.evts[m].onstime>trEst.evts[n].onstime){
				IONVEst[n]=trEst.evts[m].onstime-trEst.evts[n].onstime;
				break;
			}//endif
		}//endfor m
		if(IONVTrue[n]<0){IONVTrue[n]=trTrue.TPQN;}
		if(IONVEst[n]<0){IONVEst[n]=trEst.TPQN;}
	}//endfor n

	double NVErrorCount=0;

	vector<double> NVToIOVNRatioTrue(length);
	vector<double> NVToIOVNRatioEst(length);
	for(int n=0;n<length;n+=1){
		NVToIOVNRatioTrue[n]=double(trTrue.evts[n].offstime-trTrue.evts[n].onstime)/double(IONVTrue[n]);
		NVToIOVNRatioEst[n]=double(trEst.evts[n].offstime-trEst.evts[n].onstime)/double(IONVEst[n]);
		if((trTrue.evts[n].offstime-trTrue.evts[n].onstime)*IONVEst[n]!=(trEst.evts[n].offstime-trEst.evts[n].onstime)*IONVTrue[n]){NVErrorCount+=1;}
	}//endfor n

	double NVRatioError=0;
	double count=0;
	for(int n=0;n<length;n+=1){
		if(NVToIOVNRatioTrue[n]==0 || NVToIOVNRatioEst[n]==0){
//cout<<"Warning: Zero note value at "<<n<<"\t"<<NVToIOVNRatioTrue[n]<<"\t"<<NVToIOVNRatioEst[n]<<endl;
			continue;
		}//endif
		NVRatioError+=abs(log(NVToIOVNRatioEst[n]/NVToIOVNRatioTrue[n]));
		count+=1;
	}//endfor n
	NVRatioError/=double(count);
	NVRatioError=exp(NVRatioError);

cout<<"(Error_Rate,Scale_Error):\t"<<double(NVErrorCount)/double(length)<<"\t"<<NVRatioError<<endl;




	return 0;
}//end main
