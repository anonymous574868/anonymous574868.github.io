#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include "NVR_MRF_v170219.hpp"
using namespace std;

int main(int argc,char** argv){

	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=3){cout<<"Error in usage! : $./this in_trx.txt out_trx.txt"<<endl; return -1;}

	NVR_MRF mrf;

	ContextTree tree;
	tree.ReadFile("tree_IONVDistr_MLFull.txt");
	mrf.SetContextTree(tree);

	Trx trx;
	trx.ReadFile(string(argv[1]));
	mrf.SetTrData(trx);

	mrf.SetParameters(0.965,0.03,0.21,0.003,12);

	mrf.EstimateNVs();

	mrf.WriteFile(string(argv[2]));

	return 0;
}//end main
