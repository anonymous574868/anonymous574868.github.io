#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include "Trx_v170203.hpp"
#include "PianoRoll_v170117.hpp"
#include "KalmanSmoother_v170108.hpp"
using namespace std;

int main(int argc,char** argv){

	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=3){cout<<"Error in usage! : $./this in_trx.txt out_trx.txt"<<endl; return -1;}

	Trx trx;
	trx.ReadFile(string(argv[1]));

	vector<int> clusterOnstimes;
	vector<double> clusterOntimes;
{
	vector<double> curOntimes;
	int preOnstime=trx.evts[0].onstime;
	curOntimes.push_back(trx.evts[0].ontime);
	for(int n=1;n<trx.evts.size();n+=1){
		if(trx.evts[n].onstime!=preOnstime){
			double sum=0;
			for(int i=0;i<curOntimes.size();i+=1){sum+=curOntimes[i];}
			clusterOnstimes.push_back(preOnstime);
			clusterOntimes.push_back(sum/curOntimes.size());
			curOntimes.clear();
			preOnstime=trx.evts[n].onstime;
		}//endif
		curOntimes.push_back(trx.evts[n].ontime);
		if(n==trx.evts.size()-1){
			double sum=0;
			for(int i=0;i<curOntimes.size();i+=1){sum+=curOntimes[i];}
			clusterOnstimes.push_back(preOnstime);
			clusterOntimes.push_back(sum/curOntimes.size());
		}//endif
	}//endfor n
}//

	vector<double> x;//IOI
	vector<double> w;//note value
	for(int n=1;n<clusterOnstimes.size();n+=1){
		x.push_back(clusterOntimes[n]-clusterOntimes[n-1]);
		w.push_back(double(clusterOnstimes[n]-clusterOnstimes[n-1]));
	}//endfor n
	double Sig_v,Sig_v_ini,mu_v_ini,Sig_t;
	// v is secPerTick
	mu_v_ini=0.667/double(trx.TPQN);//90 QN per minute
	Sig_v=pow(0.03*mu_v_ini,2.);
	Sig_v_ini=Sig_v*pow(10,2.);
	Sig_t=pow(0.014,2.);//
	KalmanSmoother smoother(Sig_v,mu_v_ini,Sig_v_ini,Sig_t,x,w);
	smoother.Smooth();

	vector<double> clusterSecPerQN;
	for(int n=0;n<x.size();n+=1){
		clusterSecPerQN.push_back(smoother.z[n]*trx.TPQN);
	}//endfor n
	clusterSecPerQN.push_back(smoother.z[x.size()-1]*trx.TPQN);

	for(int n=0;n<trx.evts.size();n+=1){
		for(int m=0;m<clusterOnstimes.size();m+=1){
			if(clusterOnstimes[m]==trx.evts[n].onstime){
				trx.evts[n].secPerQN=clusterSecPerQN[m];
				break;
			}//endif
		}//endfor m
	}//endfor n

	trx.WriteFile(string(argv[2]));

	return 0;
}//end main
