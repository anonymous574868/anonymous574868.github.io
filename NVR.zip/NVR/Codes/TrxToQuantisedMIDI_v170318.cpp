#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include "Trx_v170203.hpp"
#include "PianoRoll_v170117.hpp"
using namespace std;

int main(int argc,char** argv){

	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;

	if(argc!=3){cout<<"Error in usage! : $./this in_trx.txt out.mid"<<endl; return -1;}

	Trx tr;
	tr.ReadFile(string(argv[1]));

	double secPerTick;//This is for displaying
	if(tr.meter=="Duple"){
		secPerTick=1./double(tr.TPQN);//For duple metre
	}else{
		secPerTick=(2./3.)/double(tr.TPQN);//For triple metre
	}//endif

	PianoRoll pr;
	PianoRollEvt prevt;
	for(int n=0;n<tr.evts.size()-1;n+=1){
		prevt.ID=tr.evts[n].ID;
		prevt.ontime=tr.evts[n].onstime*secPerTick;
		prevt.offtime=tr.evts[n].offstime*secPerTick;
		prevt.sitch=tr.evts[n].sitch;
		prevt.pitch=SitchToPitch(prevt.sitch);
		prevt.onvel=tr.evts[n].onvel;
		prevt.offvel=tr.evts[n].offvel;
		prevt.channel=tr.evts[n].channel;
		pr.evts.push_back(prevt);
	}//endfor n
	pr.Sort();

	pr.WriteMIDIFile(string(argv[2]));

	return 0;
}//end main
