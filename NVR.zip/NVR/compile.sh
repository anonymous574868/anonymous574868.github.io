#! /bin/bash

ProgramFolder="./Programs"
CodeFolder="./Codes"

mkdir Programs

g++ $CodeFolder/MIDIToTrx_v170318.cpp -o $ProgramFolder/MIDIToTrx
g++ -O2 $CodeFolder/RT_MetricalHMM.cpp -o $ProgramFolder/RT_MetricalHMM
g++ -O2 $CodeFolder/NVR_MRF_v170219.cpp -o $ProgramFolder/NVR_MRF
g++ -O2 $CodeFolder/NVEvaluationTool_v170318.cpp -o $ProgramFolder/NVEvaluationTool
g++ $CodeFolder/TrxToQuantisedMIDI_v170318.cpp -o $ProgramFolder/TrxToQuantisedMIDI
