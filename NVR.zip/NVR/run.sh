#! /bin/bash

if [ $# -ne 1 ]; then
echo "Error in usage: $./run.sh in(.mid)"
exit 1
fi

I1=$1

ProgramFolder="./Programs"
RelCurrentFolder="."

$ProgramFolder/MIDIToTrx $RelCurrentFolder/${I1}.mid $RelCurrentFolder/${I1}_raw_trx.txt
$ProgramFolder/RT_MetricalHMM $RelCurrentFolder/${I1}_raw_trx.txt $RelCurrentFolder/${I1}_onset_trx.txt
$ProgramFolder/NVR_MRF $RelCurrentFolder/${I1}_onset_trx.txt $RelCurrentFolder/${I1}_MRF_trx.txt 
$ProgramFolder/TrxToQuantisedMIDI $RelCurrentFolder/${I1}_MRF_trx.txt $RelCurrentFolder/${I1}_qunatised.mid

#$ProgramFolder/NVEvaluationTool groundtruth_trx.txt estimated_trx.txt 

#$ProgramFolder/TempoTracker onsetOnly_trx.txt onsetAndTempo_trx.txt 

